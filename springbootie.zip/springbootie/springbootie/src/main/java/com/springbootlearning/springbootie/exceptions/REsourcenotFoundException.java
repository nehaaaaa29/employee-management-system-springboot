package com.springbootlearning.springbootie.exceptions;

public class REsourcenotFoundException extends RuntimeException {

    public REsourcenotFoundException(String message){
        super(message);
    }
}
