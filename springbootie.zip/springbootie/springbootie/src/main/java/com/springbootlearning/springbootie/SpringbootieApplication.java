package com.springbootlearning.springbootie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootieApplication {

	public static void main(String[] args) {

		SpringApplication.run(SpringbootieApplication.class, args);
	}

}
