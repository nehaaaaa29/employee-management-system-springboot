package com.springbootlearning.springbootie.controllers;

import com.springbootlearning.springbootie.dto.EmployeeDto;
import com.springbootlearning.springbootie.entities.EmployeeEntity;
import com.springbootlearning.springbootie.exceptions.REsourcenotFoundException;
import com.springbootlearning.springbootie.repository.EmployeeRepository;
import com.springbootlearning.springbootie.services.EmployeeService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
@RequestMapping(path="/employees")
public class employeeController {
 private final EmployeeService employeeService;

    public employeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping(path="/{employeeID}")

    public ResponseEntity< EmployeeDto>  getEmployeeById(@PathVariable (name="employeeID") Long id){
        Optional<EmployeeDto> employeeDto = employeeService.getEmployeeById(id);
       return employeeDto
               .map(employeeDto1->ResponseEntity.ok(employeeDto1))
                       .orElseThrow(()-> new REsourcenotFoundException("EmployeeNotFound"));

    }

    @GetMapping
    public ResponseEntity  < List<EmployeeDto>> getAllEmployees(@Valid @RequestParam(required = false,name="inputage") Integer age,
                                                @RequestParam(required = false) String SortBy) {
        return ResponseEntity.ok(  employeeService.getAllEmployees());
    }
    @PostMapping
    public ResponseEntity<EmployeeDto> createsNewEmployee(@Valid @RequestBody EmployeeDto inputEmployee){
    EmployeeDto savedEmployee =employeeService.createNewEmployee(inputEmployee );
        return new  ResponseEntity<>(savedEmployee,HttpStatus.CREATED);
    }

    @PutMapping (path="/{employeeid}")
    public ResponseEntity<EmployeeDto> updateEmployee(@Valid @RequestBody EmployeeDto employeeDto , @PathVariable Long  employeeid){
        return ResponseEntity.ok( employeeService.updateEmployeeById(employeeid,employeeDto));
    }

    @DeleteMapping (path="/{employeeid}")
    public ResponseEntity <Boolean> deleteMapping ( @PathVariable Long  employeeid){
        boolean gotDeleted= employeeService.deleteEmployeeById(employeeid);
        if(gotDeleted)return  ResponseEntity.ok(true);
        return ResponseEntity.notFound().build();
    }

    @PatchMapping (path="/{employeeid}")

    public ResponseEntity <EmployeeDto> updatePartialEmployeeById( @Valid @RequestBody Map<String ,Object> updates, @PathVariable Long  employeeid){
       EmployeeDto employeeDto = employeeService.updatePartialEmployeeById(employeeid,updates);
       if(employeeDto ==null)return  ResponseEntity.notFound().build();
       return ResponseEntity.ok(employeeDto);
    }

}
