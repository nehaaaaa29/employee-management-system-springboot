package com.springbootlearning.springbootie.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.springbootlearning.springbootie.Annotation.EmployeeRoleValidation;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeDto {

    private Long id;


    @NotNull(message = "this field is neccessary")
    private String name;


     @Email(message = "enter a valid email")
    private String email;


@NotNull(message = "age of employee cannot be null")
@Min(value=18 , message = "your age should be greater than 18")
@Max(value=65,message = "your age should be less than 65")
    private Integer age;

@NotNull(message = "role of the employee cannot be null")
   //@Pattern(regexp = "^(ADMIN|USER)$")
@EmployeeRoleValidation
    private String role;


@NotNull(message = "salary cannot be null")
@Positive(message = "salary of employee should be positive")
private Integer salary;

   @PastOrPresent(message = "date of joining field cannot be in future")
    private LocalDate dateofjoining;


    @JsonProperty("isActive")
    private boolean isActive;
}
