package com.springbootlearning.springbootie.services;

import com.springbootlearning.springbootie.dto.EmployeeDto;
import com.springbootlearning.springbootie.entities.EmployeeEntity;
import com.springbootlearning.springbootie.exceptions.REsourcenotFoundException;
import com.springbootlearning.springbootie.repository.EmployeeRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeService {
    private final EmployeeRepository employeeRepository;
    private final ModelMapper modelMapper;

    public EmployeeService(EmployeeRepository employeeRepository, ModelMapper modelMapper) {
        this.employeeRepository = employeeRepository;
        this.modelMapper = modelMapper;
    }


    public Optional< EmployeeDto> getEmployeeById(Long id) {

//Optional<EmployeeEntity> employeeEntity = employeeRepository.findById(id);

        return employeeRepository.findById(id).map(employeeEntity -> modelMapper.map(employeeEntity,EmployeeDto.class));
    }


    public List<EmployeeDto> getAllEmployees() {

        List<EmployeeEntity> employeeEntities = employeeRepository.findAll();
        return employeeEntities
                .stream()
                .map(employeeEntity -> modelMapper.map(employeeEntity, EmployeeDto.class))
                .collect(Collectors.toList());
    }

    public EmployeeDto createNewEmployee(EmployeeDto inputEmployee) {
        EmployeeEntity tosaveEntity = modelMapper.map(inputEmployee, EmployeeEntity.class);
        EmployeeEntity saveEmployeeEntity = employeeRepository.save(tosaveEntity);
        return modelMapper.map(saveEmployeeEntity, EmployeeDto.class);
    }

    public EmployeeDto updateEmployeeById(Long employeeid, EmployeeDto employeeDto) {
       isExistsByEmployeeId(employeeid);
        EmployeeEntity employeeEntity = modelMapper.map(employeeDto, EmployeeEntity.class);
        employeeEntity.setId(employeeid);
        EmployeeEntity savedEmployeeEntity = employeeRepository.save(employeeEntity);
        return modelMapper.map(savedEmployeeEntity, EmployeeDto.class);
    }
    public void isExistsByEmployeeId(Long employeeid){
        boolean exits = employeeRepository.existsById(employeeid);
        if (!exits) throw new  REsourcenotFoundException("EmployeeNotFound With this id"+employeeid);

    }

    public boolean deleteEmployeeById(Long employeeid) {

       isExistsByEmployeeId(employeeid);

        employeeRepository.deleteById(employeeid);
        return true;
    }

    public EmployeeDto updatePartialEmployeeById(Long employeeid, Map<String, Object> updates) {
         isExistsByEmployeeId(employeeid);

        EmployeeEntity employeeEntity= employeeRepository.findById(employeeid).get();
        updates.forEach((field,value) -> {
            Field fieldToBeUpdated= ReflectionUtils.findField(EmployeeEntity.class,field);
            fieldToBeUpdated.setAccessible(true);
            ReflectionUtils.setField(fieldToBeUpdated,employeeEntity,value);

        });
       return modelMapper.map (employeeRepository.save(employeeEntity),EmployeeDto.class);

    }
}

