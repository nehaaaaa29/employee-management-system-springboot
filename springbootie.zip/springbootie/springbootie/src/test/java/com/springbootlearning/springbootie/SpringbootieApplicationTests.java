package com.springbootlearning.springbootie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootieApplicationTests {

	@Test
	void contextLoads() {
	}

}
